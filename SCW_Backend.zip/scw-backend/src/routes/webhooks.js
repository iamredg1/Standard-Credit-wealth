// ═══════════════════════════════════════════════════════════
// WEBHOOKS — /api/webhooks
// Receives events from Systeme.io and PayPal
// ═══════════════════════════════════════════════════════════
const express = require('express');
const router = express.Router();
const supabase = require('../lib/supabase');
const { sendWelcomeEmail, sendPurchaseConfirmation, sendPMAConfirmation, notifyFounderPMA } = require('../lib/email');

// PRODUCT MAP — map Systeme.io product names to SCW tiers
const MEMBERSHIP_PRODUCTS = [
  'standard credit wealth standard membership',
  'scw standard membership',
  'standard membership',
  'scw premium membership',
  'standard credit wealth premium membership',
  'premium membership'
];

const GUIDEBOOK_MAP = {
  'when the system gets it wrong': { file: 'scw-guide-01-when-system-gets-it-wrong.pdf', name: 'When the System Gets It Wrong' },
  'consumer credit playbook': { file: 'scw-guide-02-consumer-credit-playbook.pdf', name: 'Consumer Credit Playbook' },
  'ucc decoded': { file: 'scw-guide-03-ucc-decoded.pdf', name: 'The UCC Decoded' },
  'first property playbook': { file: 'scw-guide-04-first-property-playbook.pdf', name: 'First Property Playbook' },
  'tax strategy guide': { file: 'scw-guide-05-tax-strategy-guide.pdf', name: 'Tax Strategy Guide' },
  'bank like the wealthy': { file: 'scw-guide-06-bank-like-the-wealthy.pdf', name: 'Bank Like the Wealthy' },
  'trust and estate': { file: 'scw-guide-07-trust-estate-guide.pdf', name: 'Trust & Estate Guide' },
  'fight back': { file: 'scw-guide-08-fight-back-udaap.pdf', name: 'Fight Back: UDAAP Guide' },
  'average joe to tycoon': { file: 'scw-guide-09-average-joe-to-tycoon.pdf', name: 'Average Joe to Tycoon' },
  'legal bundle': { file: 'scw-bundle-legal.pdf', name: 'Legal Bundle' },
  'wealth builder bundle': { file: 'scw-bundle-wealth-builder.pdf', name: 'Wealth Builder Bundle' },
  'complete collection': { file: 'scw-bundle-complete-collection.pdf', name: 'Complete Collection' }
};

function matchProduct(productName) {
  const lower = (productName || '').toLowerCase();
  for (const [key, val] of Object.entries(GUIDEBOOK_MAP)) {
    if (lower.includes(key)) return { type: 'guidebook', ...val };
  }
  for (const m of MEMBERSHIP_PRODUCTS) {
    if (lower.includes(m)) {
      const tier = lower.includes('premium') ? 'premium' : 'standard';
      return { type: 'membership', tier };
    }
  }
  return null;
}

// ── SYSTEME.IO WEBHOOK ───────────────────────────────────────
// POST /api/webhooks/systemio
router.post('/systemio', async (req, res) => {
  const event = req.body;
  console.log('Systeme.io webhook:', JSON.stringify(event, null, 2));

  try {
    const { event_type, contact, order } = event;

    if (event_type === 'order.completed' || event_type === 'purchase.completed') {
      const email = contact?.email;
      const firstName = contact?.first_name || '';
      const lastName = contact?.last_name || '';
      const productName = order?.product?.name || order?.name || '';

      if (!email) {
        return res.status(400).json({ error: 'No email in webhook' });
      }

      const product = matchProduct(productName);

      if (product?.type === 'membership') {
        // Create or update member account
        const { data: existing } = await supabase
          .from('members')
          .select('id, user_id')
          .eq('email', email)
          .single();

        if (!existing) {
          // Create Supabase auth user with temp password
          const tempPassword = Math.random().toString(36).slice(-10) + 'Scw!';
          
          const { data: authData } = await supabase.auth.admin.createUser({
            email,
            password: tempPassword,
            email_confirm: true
          });

          if (authData?.user) {
            await supabase.from('members').insert({
              user_id: authData.user.id,
              email,
              first_name: firstName,
              last_name: lastName,
              membership_tier: product.tier,
              membership_status: 'active',
              systemeio_contact_id: contact?.id,
              xp: 0,
              level: 1,
              badges: [],
              courses_completed: [],
              quizzes_completed: [],
              created_at: new Date().toISOString()
            });

            // Send welcome email with portal access
            await sendWelcomeEmail(email, firstName, product.tier);
          }
        } else {
          // Update existing member
          await supabase
            .from('members')
            .update({
              membership_tier: product.tier,
              membership_status: 'active',
              updated_at: new Date().toISOString()
            })
            .eq('email', email);
        }
      }

      if (product?.type === 'guidebook') {
        // Send guidebook download
        const downloadUrl = `${process.env.APP_URL}/downloads/${product.file}`;
        await sendPurchaseConfirmation(email, firstName, product.name, downloadUrl);

        // Log purchase
        await supabase.from('purchases').insert({
          email,
          product_name: product.name,
          product_file: product.file,
          order_id: order?.id,
          created_at: new Date().toISOString()
        });
      }
    }

    if (event_type === 'subscription.cancelled' || event_type === 'subscription.expired') {
      const email = contact?.email;
      if (email) {
        await supabase
          .from('members')
          .update({ membership_status: 'cancelled', updated_at: new Date().toISOString() })
          .eq('email', email);
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── PAYPAL WEBHOOK ───────────────────────────────────────────
// POST /api/webhooks/paypal
router.post('/paypal', async (req, res) => {
  const event = req.body;
  console.log('PayPal webhook:', event.event_type);

  try {
    if (event.event_type === 'PAYMENT.SALE.COMPLETED') {
      const email = event.resource?.payer?.payer_info?.email;
      const amount = event.resource?.amount?.total;
      const description = event.resource?.description || '';

      await supabase.from('paypal_transactions').insert({
        paypal_transaction_id: event.resource?.id,
        email,
        amount,
        description,
        raw_event: event,
        created_at: new Date().toISOString()
      });
    }

    res.json({ received: true });
  } catch (err) {
    console.error('PayPal webhook error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── PMA APPLICATION ──────────────────────────────────────────
// POST /api/webhooks/pma
router.post('/pma', async (req, res) => {
  const appData = req.body;

  try {
    // Generate reference
    const ref = 'SCW-PMA-' + Date.now().toString().slice(-6);
    appData.ref = ref;
    appData.submittedAt = new Date().toISOString();
    appData.status = 'pending';

    // Save to database
    await supabase.from('pma_applications').insert({
      ref,
      first_name: appData.first,
      last_name: appData.last,
      email: appData.email,
      phone: appData.phone,
      location: appData.location,
      source: appData.source,
      current_status: appData.status,
      scw_level: appData.scwLevel,
      tier_selected: appData.tier,
      goal_12_month: appData.goal12,
      looking_for: appData.lookingFor,
      brings_to_pma: appData.brings,
      attendance_commitment: appData.attend,
      additional_notes: appData.anything,
      application_status: 'pending',
      created_at: new Date().toISOString()
    });

    // Send confirmation to applicant
    await sendPMAConfirmation(appData.email, appData.first, ref);

    // Notify founder
    await notifyFounderPMA(appData);

    res.json({ success: true, ref });
  } catch (err) {
    console.error('PMA webhook error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
