// ═══════════════════════════════════════════════════════════
// COURSES ROUTES — /api/courses
// ═══════════════════════════════════════════════════════════
const express = require('express');
const router = express.Router();
const supabase = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');

// POST /api/courses/complete — mark a module complete and award XP
router.post('/complete', requireAuth, async (req, res) => {
  const { moduleId, moduleName, trackId, levelId } = req.body;

  // Check if already completed
  const { data: member } = await supabase
    .from('members')
    .select('xp, courses_completed')
    .eq('user_id', req.user.id)
    .single();

  const completed = member.courses_completed || [];
  const alreadyDone = completed.includes(moduleId);

  if (!alreadyDone) {
    completed.push(moduleId);
    const newXP = (member.xp || 0) + 100;

    await supabase
      .from('members')
      .update({
        courses_completed: completed,
        xp: newXP,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', req.user.id);

    await supabase.from('xp_log').insert({
      user_id: req.user.id,
      action: 'MODULE_COMPLETE',
      xp_earned: 100,
      metadata: { moduleId, moduleName, trackId, levelId },
      created_at: new Date().toISOString()
    });
  }

  res.json({
    success: true,
    xpEarned: alreadyDone ? 0 : 100,
    alreadyCompleted: alreadyDone
  });
});

// GET /api/courses/progress
router.get('/progress', requireAuth, async (req, res) => {
  const { data: member } = await supabase
    .from('members')
    .select('courses_completed, xp, level')
    .eq('user_id', req.user.id)
    .single();

  res.json({
    completed: member.courses_completed || [],
    totalCompleted: (member.courses_completed || []).length,
    xp: member.xp || 0,
    level: member.level || 1
  });
});

module.exports = router;
