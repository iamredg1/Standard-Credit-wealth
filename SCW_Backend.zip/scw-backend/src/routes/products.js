// ═══════════════════════════════════════════════════════════
// PRODUCTS ROUTES — /api/products
// ═══════════════════════════════════════════════════════════
const express = require('express');
const router = express.Router();

// All SCW products — update checkout URLs with your Systeme.io links
const PRODUCTS = {
  guidebooks: [
    { id: 'GB01', name: 'When the System Gets It Wrong', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb01' },
    { id: 'GB02', name: 'Consumer Credit Playbook', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb02' },
    { id: 'GB03', name: 'The UCC Decoded', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb03' },
    { id: 'GB04', name: 'First Property Playbook', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb04' },
    { id: 'GB05', name: 'Tax Strategy Guide', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb05' },
    { id: 'GB06', name: 'Bank Like the Wealthy', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb06' },
    { id: 'GB07', name: 'Trust & Estate Guide', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb07' },
    { id: 'GB08', name: 'Fight Back: UDAAP Guide', price: 17, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb08' },
    { id: 'GB09', name: 'Average Joe to Tycoon', price: 27, checkoutUrl: 'https://standardcreditwealth.systeme.io/gb09' }
  ],
  bundles: [
    { id: 'BUNDLE-LEGAL', name: 'Legal Bundle', price: 37, includes: ['GB01','GB02','GB08'], checkoutUrl: 'https://standardcreditwealth.systeme.io/bundle-legal' },
    { id: 'BUNDLE-WEALTH', name: 'Wealth Builder Bundle', price: 37, includes: ['GB03','GB04','GB05','GB06'], checkoutUrl: 'https://standardcreditwealth.systeme.io/bundle-wealth' },
    { id: 'BUNDLE-ALL', name: 'Complete Collection', price: 97, includes: ['GB01','GB02','GB03','GB04','GB05','GB06','GB07','GB08','GB09'], checkoutUrl: 'https://standardcreditwealth.systeme.io/bundle-all' }
  ],
  memberships: [
    { id: 'MEM-STANDARD', name: 'Standard Membership', price: 29, billing: 'monthly', checkoutUrl: 'https://standardcreditwealth.systeme.io/standard-monthly' },
    { id: 'MEM-STANDARD-ANNUAL', name: 'Standard Membership Annual', price: 197, billing: 'annual', checkoutUrl: 'https://standardcreditwealth.systeme.io/standard-annual' },
    { id: 'MEM-PREMIUM', name: 'Premium Membership', price: 297, billing: 'monthly', checkoutUrl: 'https://standardcreditwealth.systeme.io/premium-monthly' },
    { id: 'MEM-PREMIUM-ANNUAL', name: 'Premium Membership Annual', price: 2497, billing: 'annual', checkoutUrl: 'https://standardcreditwealth.systeme.io/premium-annual' }
  ]
};

// GET /api/products
router.get('/', (req, res) => {
  res.json(PRODUCTS);
});

// GET /api/products/:id
router.get('/:id', (req, res) => {
  const all = [...PRODUCTS.guidebooks, ...PRODUCTS.bundles, ...PRODUCTS.memberships];
  const product = all.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

module.exports = router;
