// ═══════════════════════════════════════════════════════════
// QUIZ ROUTES — /api/quiz
// ═══════════════════════════════════════════════════════════
const express = require('express');
const router = express.Router();
const supabase = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');

// POST /api/quiz/complete — save quiz result and award XP
router.post('/complete', requireAuth, async (req, res) => {
  const { quizId, quizName, score, total, passed, timeTaken } = req.body;

  const pct = Math.round((score / total) * 100);

  // Save quiz result
  const { data: result, error } = await supabase
    .from('quiz_results')
    .insert({
      user_id: req.user.id,
      quiz_id: quizId,
      quiz_name: quizName,
      score,
      total,
      percentage: pct,
      passed,
      time_taken: timeTaken,
      created_at: new Date().toISOString()
    })
    .select()
    .single();

  if (error) {
    return res.status(400).json({ error: error.message });
  }

  // Calculate XP earned
  let xpEarned = 0;
  if (passed) {
    xpEarned += 500; // Quiz pass
    if (pct === 100) xpEarned += 250; // Perfect score bonus
  }

  // Update member XP and quiz history
  const { data: member } = await supabase
    .from('members')
    .select('xp, quizzes_completed')
    .eq('user_id', req.user.id)
    .single();

  const quizzesCompleted = member.quizzes_completed || [];
  if (!quizzesCompleted.includes(quizId)) {
    quizzesCompleted.push(quizId);
  }

  await supabase
    .from('members')
    .update({
      xp: (member.xp || 0) + xpEarned,
      quizzes_completed: quizzesCompleted,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', req.user.id);

  // Log XP
  if (xpEarned > 0) {
    await supabase.from('xp_log').insert({
      user_id: req.user.id,
      action: pct === 100 ? 'QUIZ_PERFECT' : 'QUIZ_PASS',
      xp_earned: xpEarned,
      metadata: { quizId, quizName, score: pct },
      created_at: new Date().toISOString()
    });
  }

  res.json({
    success: true,
    xpEarned,
    percentage: pct,
    passed,
    resultId: result.id
  });
});

// GET /api/quiz/history — get member's quiz history
router.get('/history', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('quiz_results')
    .select('*')
    .eq('user_id', req.user.id)
    .order('created_at', { ascending: false });

  if (error) return res.status(400).json({ error: error.message });
  res.json({ results: data });
});

// GET /api/quiz/stats — aggregate stats
router.get('/stats', requireAuth, async (req, res) => {
  const { data } = await supabase
    .from('quiz_results')
    .select('*')
    .eq('user_id', req.user.id);

  if (!data || data.length === 0) {
    return res.json({ totalTaken: 0, totalPassed: 0, avgScore: 0, perfectScores: 0 });
  }

  const stats = {
    totalTaken: data.length,
    totalPassed: data.filter(r => r.passed).length,
    avgScore: Math.round(data.reduce((a, r) => a + r.percentage, 0) / data.length),
    perfectScores: data.filter(r => r.percentage === 100).length,
    quizzesByName: {}
  };

  data.forEach(r => {
    if (!stats.quizzesByName[r.quiz_name]) {
      stats.quizzesByName[r.quiz_name] = { attempts: 0, bestScore: 0 };
    }
    stats.quizzesByName[r.quiz_name].attempts++;
    stats.quizzesByName[r.quiz_name].bestScore = Math.max(
      stats.quizzesByName[r.quiz_name].bestScore, r.percentage
    );
  });

  res.json(stats);
});

module.exports = router;
