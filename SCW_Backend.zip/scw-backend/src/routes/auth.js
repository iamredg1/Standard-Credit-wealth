// ═══════════════════════════════════════════════════════════
// AUTH ROUTES — /api/auth
// ═══════════════════════════════════════════════════════════
const express = require('express');
const router = express.Router();
const supabase = require('../lib/supabase');
const { sendWelcomeEmail } = require('../lib/email');

// POST /api/auth/signup
router.post('/signup', async (req, res) => {
  const { email, password, firstName, lastName, membershipTier = 'standard' } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  // Create auth user
  const { data: authData, error: authError } = await supabase.auth.admin.createUser({
    email,
    password,
    email_confirm: true
  });

  if (authError) {
    return res.status(400).json({ error: authError.message });
  }

  // Create member profile
  const { error: profileError } = await supabase
    .from('members')
    .insert({
      user_id: authData.user.id,
      email,
      first_name: firstName || '',
      last_name: lastName || '',
      membership_tier: membershipTier,
      membership_status: 'active',
      xp: 0,
      level: 1,
      badges: [],
      courses_completed: [],
      quizzes_completed: [],
      created_at: new Date().toISOString()
    });

  if (profileError) {
    console.error('Profile creation error:', profileError);
  }

  // Send welcome email
  try {
    await sendWelcomeEmail(email, firstName, membershipTier);
  } catch (e) {
    console.error('Welcome email failed:', e.message);
  }

  res.json({ 
    success: true, 
    message: 'Account created. Welcome to SCW.',
    userId: authData.user.id
  });
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  // Get member profile
  const { data: member } = await supabase
    .from('members')
    .select('*')
    .eq('user_id', data.user.id)
    .single();

  res.json({
    success: true,
    token: data.session.access_token,
    user: {
      id: data.user.id,
      email: data.user.email,
      firstName: member?.first_name,
      lastName: member?.last_name,
      tier: member?.membership_tier,
      status: member?.membership_status,
      xp: member?.xp || 0,
      level: member?.level || 1,
      badges: member?.badges || []
    }
  });
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token) {
    await supabase.auth.admin.signOut(token);
  }
  res.json({ success: true });
});

// POST /api/auth/reset-password
router.post('/reset-password', async (req, res) => {
  const { email } = req.body;
  
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${process.env.APP_URL}/reset`
  });

  if (error) {
    return res.status(400).json({ error: error.message });
  }

  res.json({ success: true, message: 'Password reset email sent' });
});

module.exports = router;
