// ═══════════════════════════════════════════════════════════
// MEMBERS ROUTES — /api/members
// ═══════════════════════════════════════════════════════════
const express = require('express');
const router = express.Router();
const supabase = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');

// XP VALUES
const XP = {
  MODULE_COMPLETE: 100,
  QUIZ_PASS: 500,
  QUIZ_PERFECT: 750,
  TRACK_COMPLETE: 1000,
  LEVEL_UNLOCK: 2500,
  DAILY_STREAK: 50,
  PMA_APPLICATION: 5000
};

// LEVEL THRESHOLDS
const LEVELS = [
  { level: 1, name: 'Foundation',  xp: 0,     color: '#2D7A4F', badge: '🌱' },
  { level: 2, name: 'Awakening',   xp: 10000, color: '#2D7A7A', badge: '👁️' },
  { level: 3, name: 'Builder',     xp: 25000, color: '#BF9B4E', badge: '🔨' },
  { level: 4, name: 'Strategist',  xp: 50000, color: '#7B4FB0', badge: '⚖️' },
  { level: 5, name: 'Tycoon',      xp: 100000,color: '#8B2020', badge: '👑' }
];

function calculateLevel(xp) {
  let current = LEVELS[0];
  for (const l of LEVELS) {
    if (xp >= l.xp) current = l;
  }
  const nextIdx = LEVELS.findIndex(l => l.level === current.level + 1);
  const next = nextIdx >= 0 ? LEVELS[nextIdx] : null;
  const progress = next ? Math.round(((xp - current.xp) / (next.xp - current.xp)) * 100) : 100;
  return { current, next, progress };
}

// GET /api/members/me
router.get('/me', requireAuth, async (req, res) => {
  const { data: member, error } = await supabase
    .from('members')
    .select('*')
    .eq('user_id', req.user.id)
    .single();

  if (error || !member) {
    return res.status(404).json({ error: 'Member profile not found' });
  }

  const levelInfo = calculateLevel(member.xp || 0);

  res.json({
    ...member,
    levelInfo,
    levelName: levelInfo.current.name,
    levelBadge: levelInfo.current.badge,
    levelProgress: levelInfo.progress,
    nextLevelXP: levelInfo.next?.xp || null
  });
});

// PUT /api/members/me
router.put('/me', requireAuth, async (req, res) => {
  const { firstName, lastName, phone, location } = req.body;

  const { data, error } = await supabase
    .from('members')
    .update({
      first_name: firstName,
      last_name: lastName,
      phone,
      location,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', req.user.id)
    .select()
    .single();

  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true, member: data });
});

// POST /api/members/xp — award XP for an action
router.post('/xp', requireAuth, async (req, res) => {
  const { action, metadata = {} } = req.body;

  const xpAmount = XP[action];
  if (!xpAmount) {
    return res.status(400).json({ error: 'Unknown XP action' });
  }

  // Get current member
  const { data: member } = await supabase
    .from('members')
    .select('xp, level, badges')
    .eq('user_id', req.user.id)
    .single();

  const newXP = (member.xp || 0) + xpAmount;
  const levelInfo = calculateLevel(newXP);
  const newLevel = levelInfo.current.level;
  const leveledUp = newLevel > (member.level || 1);

  // Update XP and level
  const { data: updated } = await supabase
    .from('members')
    .update({
      xp: newXP,
      level: newLevel,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', req.user.id)
    .select()
    .single();

  // Log XP transaction
  await supabase.from('xp_log').insert({
    user_id: req.user.id,
    action,
    xp_earned: xpAmount,
    metadata,
    created_at: new Date().toISOString()
  });

  res.json({
    success: true,
    xpEarned: xpAmount,
    totalXP: newXP,
    level: newLevel,
    leveledUp,
    levelInfo: calculateLevel(newXP)
  });
});

// GET /api/members/leaderboard
router.get('/leaderboard', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('members')
    .select('first_name, last_name, xp, level, badges, membership_tier')
    .eq('membership_status', 'active')
    .order('xp', { ascending: false })
    .limit(20);

  if (error) return res.status(400).json({ error: error.message });

  const leaderboard = data.map((m, i) => ({
    rank: i + 1,
    name: `${m.first_name} ${m.last_name?.charAt(0) || ''}.`,
    xp: m.xp || 0,
    level: m.level || 1,
    levelInfo: calculateLevel(m.xp || 0),
    tier: m.membership_tier
  }));

  res.json({ leaderboard });
});

// POST /api/members/streak — check and update daily streak
router.post('/streak', requireAuth, async (req, res) => {
  const { data: member } = await supabase
    .from('members')
    .select('last_active, streak_days, xp')
    .eq('user_id', req.user.id)
    .single();

  const today = new Date().toDateString();
  const lastActive = member.last_active ? new Date(member.last_active).toDateString() : null;
  const yesterday = new Date(Date.now() - 86400000).toDateString();

  let newStreak = member.streak_days || 0;
  let xpEarned = 0;

  if (lastActive !== today) {
    if (lastActive === yesterday) {
      newStreak += 1;
    } else if (lastActive !== today) {
      newStreak = 1;
    }
    xpEarned = XP.DAILY_STREAK;

    await supabase
      .from('members')
      .update({
        last_active: new Date().toISOString(),
        streak_days: newStreak,
        xp: (member.xp || 0) + xpEarned
      })
      .eq('user_id', req.user.id);
  }

  res.json({ streak: newStreak, xpEarned, alreadyLoggedToday: lastActive === today });
});

module.exports = router;
