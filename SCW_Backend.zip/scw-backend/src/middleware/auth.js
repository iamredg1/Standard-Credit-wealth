// ═══════════════════════════════════════════════════════════
// AUTH MIDDLEWARE
// ═══════════════════════════════════════════════════════════
const supabase = require('../lib/supabase');

async function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const { data: { user }, error } = await supabase.auth.getUser(token);
  
  if (error || !user) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  req.user = user;
  next();
}

async function requireMembership(tier) {
  return async (req, res, next) => {
    const { data: member } = await supabase
      .from('members')
      .select('membership_tier, membership_status')
      .eq('user_id', req.user.id)
      .single();

    if (!member || member.membership_status !== 'active') {
      return res.status(403).json({ error: 'Active membership required' });
    }

    if (tier === 'premium' && member.membership_tier !== 'premium') {
      return res.status(403).json({ error: 'Premium membership required' });
    }

    req.member = member;
    next();
  };
}

module.exports = { requireAuth, requireMembership };
