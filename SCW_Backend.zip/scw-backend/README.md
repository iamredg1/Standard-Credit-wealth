# Standard Credit Wealth — Backend

## Setup in GitHub Codespaces

### Step 1 — Install dependencies
Paste this in the terminal:
```bash
npm install
```

### Step 2 — Create your .env file
```bash
cp .env.example .env
```
Then open .env and fill in your values:
- SUPABASE_URL — from supabase.com → your project → Settings → API
- SUPABASE_SERVICE_KEY — from same page (service_role key)
- PAYPAL_CLIENT_ID — from developer.paypal.com
- EMAIL_USER — rmerchant@standardcredit.org
- EMAIL_PASS — your email password
- APP_URL — https://standardcreditwealth.com
- JWT_SECRET — any long random string

### Step 3 — Set up Supabase database
1. Go to supabase.com → your project
2. Click SQL Editor
3. Paste the entire contents of supabase-schema.sql
4. Click Run

### Step 4 — Run the server
```bash
npm start
```

You should see:
```
╔════════════════════════════════════════╗
║   STANDARD CREDIT WEALTH BACKEND      ║
║   Running on port 3000                ║
╚════════════════════════════════════════╝
```

### Step 5 — Test it
Open a new terminal tab and run:
```bash
curl http://localhost:3000/api/health
```
You should see: `{"status":"SCW Backend Running",...}`

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/signup | Create member account |
| POST | /api/auth/login | Login and get token |
| GET | /api/members/me | Get logged-in member profile |
| POST | /api/members/xp | Award XP for an action |
| GET | /api/members/leaderboard | Top members by XP |
| POST | /api/quiz/complete | Save quiz result + award XP |
| GET | /api/quiz/history | Member quiz history |
| POST | /api/courses/complete | Mark module complete + XP |
| GET | /api/courses/progress | Member course progress |
| POST | /api/webhooks/systemio | Systeme.io purchase webhook |
| POST | /api/webhooks/paypal | PayPal payment webhook |
| POST | /api/webhooks/pma | PMA application submission |
| GET | /api/products | All SCW products |

## Webhook Setup in Systeme.io
1. Go to Systeme.io → Settings → Webhooks
2. Add webhook URL: https://YOUR-DOMAIN.com/api/webhooks/systemio
3. Select events: order.completed, subscription.cancelled

## Known. Built. Owned. Protected.
Standard Credit Wealth — From Average Joe to Tycoon
