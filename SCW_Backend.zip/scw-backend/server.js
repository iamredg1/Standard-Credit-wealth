// ═══════════════════════════════════════════════════════════
// STANDARD CREDIT WEALTH — MAIN SERVER
// ═══════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ── MIDDLEWARE ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── ROUTES ───────────────────────────────────────────────────
app.use('/api/auth',     require('./src/routes/auth'));
app.use('/api/members',  require('./src/routes/members'));
app.use('/api/courses',  require('./src/routes/courses'));
app.use('/api/quiz',     require('./src/routes/quiz'));
app.use('/api/webhooks', require('./src/routes/webhooks'));
app.use('/api/products', require('./src/routes/products'));

// ── SERVE FRONTEND ───────────────────────────────────────────
// Serve the member portal for all non-API routes
app.get('/portal', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'portal.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── HEALTH CHECK ─────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'SCW Backend Running', 
    time: new Date().toISOString(),
    version: '1.0.0'
  });
});

// ── START ────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
  ╔════════════════════════════════════════╗
  ║   STANDARD CREDIT WEALTH BACKEND      ║
  ║   Running on port ${PORT}                ║
  ║   Know. Build. Own. Protect.           ║
  ╚════════════════════════════════════════╝
  `);
});

module.exports = app;
