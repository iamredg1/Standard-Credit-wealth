-- ═══════════════════════════════════════════════════════════
-- STANDARD CREDIT WEALTH — SUPABASE DATABASE SCHEMA
-- Paste this into your Supabase SQL Editor and run it
-- ═══════════════════════════════════════════════════════════

-- MEMBERS TABLE
create table if not exists members (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade,
  email text unique not null,
  first_name text default '',
  last_name text default '',
  phone text default '',
  location text default '',
  membership_tier text default 'standard' check (membership_tier in ('standard','premium','pma')),
  membership_status text default 'active' check (membership_status in ('active','cancelled','expired','paused')),
  systemeio_contact_id text,
  xp integer default 0,
  level integer default 1,
  streak_days integer default 0,
  last_active timestamptz,
  badges jsonb default '[]',
  courses_completed jsonb default '[]',
  quizzes_completed jsonb default '[]',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- QUIZ RESULTS TABLE
create table if not exists quiz_results (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade,
  quiz_id text not null,
  quiz_name text not null,
  score integer not null,
  total integer not null,
  percentage integer not null,
  passed boolean not null,
  time_taken integer,
  created_at timestamptz default now()
);

-- XP LOG TABLE
create table if not exists xp_log (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade,
  action text not null,
  xp_earned integer not null,
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

-- PURCHASES TABLE
create table if not exists purchases (
  id uuid default gen_random_uuid() primary key,
  email text not null,
  product_name text not null,
  product_file text,
  order_id text,
  amount numeric,
  created_at timestamptz default now()
);

-- PMA APPLICATIONS TABLE
create table if not exists pma_applications (
  id uuid default gen_random_uuid() primary key,
  ref text unique not null,
  first_name text,
  last_name text,
  email text not null,
  phone text,
  location text,
  source text,
  current_status text,
  scw_level text,
  tier_selected text,
  goal_12_month text,
  looking_for text,
  brings_to_pma text,
  attendance_commitment text,
  additional_notes text,
  application_status text default 'pending' check (application_status in ('pending','accepted','rejected','waitlist')),
  reviewer_notes text,
  created_at timestamptz default now(),
  reviewed_at timestamptz
);

-- PAYPAL TRANSACTIONS TABLE
create table if not exists paypal_transactions (
  id uuid default gen_random_uuid() primary key,
  paypal_transaction_id text unique,
  email text,
  amount numeric,
  description text,
  raw_event jsonb,
  created_at timestamptz default now()
);

-- EMAIL LEADS TABLE (from quiz captures)
create table if not exists email_leads (
  id uuid default gen_random_uuid() primary key,
  email text not null,
  first_name text default '',
  source text,
  quiz_name text,
  quiz_score integer,
  quiz_passed boolean,
  created_at timestamptz default now()
);

-- ── ROW LEVEL SECURITY ───────────────────────────────────────
alter table members enable row level security;
alter table quiz_results enable row level security;
alter table xp_log enable row level security;

-- Members can only see their own data
create policy "Members see own profile" on members
  for select using (auth.uid() = user_id);

create policy "Members update own profile" on members
  for update using (auth.uid() = user_id);

create policy "Members see own quiz results" on quiz_results
  for select using (auth.uid() = user_id);

create policy "Members insert own quiz results" on quiz_results
  for insert with check (auth.uid() = user_id);

create policy "Members see own XP log" on xp_log
  for select using (auth.uid() = user_id);

-- Leaderboard — members can see XP/level of all active members
create policy "Leaderboard visible to all members" on members
  for select using (membership_status = 'active');

-- ── INDEXES ──────────────────────────────────────────────────
create index if not exists members_email_idx on members(email);
create index if not exists members_xp_idx on members(xp desc);
create index if not exists quiz_results_user_idx on quiz_results(user_id);
create index if not exists xp_log_user_idx on xp_log(user_id);
create index if not exists pma_ref_idx on pma_applications(ref);

-- ── DONE ─────────────────────────────────────────────────────
-- Run this entire file in Supabase SQL Editor
-- Then go back to Claude and paste your Project URL and anon key
